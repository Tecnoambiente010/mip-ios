# Tecnoambiente MIP · APK Android

**Origen de la aplicación:** https://tecnoambiente010.github.io/mip-ios/ (formulario Metro/Ruta publicado por Tecnoambiente010).

## Funciones

- Abre el formulario original y mantiene su estilo y comportamiento.
- Soporta selección de fotografías y cámara externa con resolución completa usando el selector nativo de Android.
- Permite firmar directamente en las áreas táctiles del formulario.
- Intercepta descargas `blob:` de PDF y DOCX y abre el cuadro **Guardar como** de Android para que el técnico elija una carpeta. No se requieren permisos de almacenamiento.
- Mantiene `localStorage`, IndexedDB y Service Worker de la página; con la primera carga y caché correctas, puede utilizar los recursos ya almacenados sin conexión. **No está garantizada la operación 100 % sin conexión**.
- Restringe navegación embebida al origen HTTPS de Tecnoambiente; no permite tráfico HTTP ni acceso de archivos arbitrarios desde la WebView.
- Compatible desde Android 8 (API 26). Configurado con SDK 35 para Android 15, firmado por Android Gradle Plugin en APK de prueba (esquema v2/v3).

## Instalar el APK

1. Descarga **Tecnoambiente-MIP-Android.apk** desde la sección **Releases** del repositorio (cuando la compilación GitHub Actions finalice correctamente).
2. Abre el archivo desde *Descargas* o *Archivos*. Android puede pedir autorización **Instalar apps desconocidas** para el navegador o gestor de archivos.
3. Abre **Tecnoambiente MIP** con Internet la primera vez.
4. Completa los antecedentes, fotos y firmas. Pulsa **Descargar PDF** o **Descargar DOCX**, escoge la carpeta y toca **Guardar**.
5. Verifica el documento antes de limpiar el formulario.

## Construcción desde código fuente

1. Abrir la carpeta `android/` en Android Studio con JDK 17, Android SDK 35.
2. Sincronizar Gradle (Android Gradle Plugin 8.8.2, Gradle 8.10.2) y ejecutar `:app:assembleDebug`.
3. El instalador queda en `android/app/build/outputs/apk/debug/app-debug.apk`.
4. En este repositorio el workflow `.github/workflows/build-android.yml` realiza ese proceso y adjunta el instalador en GitHub Actions; también intenta publicarlo como descarga directa en **Releases**.

## Advertencias de producción

- El paquete generado por el workflow es **de prueba, firmado con clave debug** del runner. Entre recompilaciones puede cambiar la clave y Android exigir desinstalar la versión anterior para actualizar. **Antes de un despliegue permanente generar y conservar una keystore corporativa y firmar la variante release**; no publicar claves en el repositorio.
- No almacena ni envía informes a Supabase automáticamente. La información se guarda conforme al formulario web; el trabajador debe exportar y resguardar el PDF/DOCX.
- Como WebView del sitio publicado, requiere que su dominio esté accesible en la primera apertura y recibe los cambios del sitio sin reinstalar el APK. Esto también implica dependencia de la integridad del sitio.
- GitHub Releases y GitHub Actions requieren que el permiso **Actions > General > Workflow permissions** sea adecuado para publicar archivos en Releases. Si no, el workflow deja el APK compilado en **Actions > Artifacts**.
- No se ha ejecutado una prueba física en teléfonos en este entorno. Validar especialmente firmas, fotos, PDF/DOCX, rotación, segundo arranque y conservación del borrador antes de desplegar masivamente.

## Licencias y atribuciones

La APK no redistribuye el HTML ni las bibliotecas web: carga el sitio alojado en GitHub Pages. El frontend ya incluye su propia copia de jsPDF y licencias en el repositorio del sitio.
