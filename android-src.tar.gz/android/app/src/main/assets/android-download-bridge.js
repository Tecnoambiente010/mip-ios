/* Inyectado por la APK en el origen https://tecnoambiente010.github.io/mip-ios/.
   Intercepta SOLO el clic de archivos generados por la pagina con blob:.
   No modifica la pagina de GitHub Pages ni las firmas, fotos o datos del formulario. */
(function () {
  'use strict';
  if (window.__mipAndroidBridgeReady) return;
  window.__mipAndroidBridgeReady = true;
  var MAX_FILE = 100 * 1024 * 1024;
  var running = false;

  function readBase64(blob) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () {
        var value = String(reader.result || '');
        var comma = value.indexOf(',');
        if (comma < 0) reject(new Error('Formato de datos invalido'));
        else resolve(value.substring(comma + 1));
      };
      reader.onerror = function () { reject(new Error('No fue posible leer el archivo')); };
      reader.readAsDataURL(blob);
    });
  }

  async function saveToAndroid(blob, name) {
    if (running) { alert('Finaliza el guardado anterior antes de descargar otro informe.'); return; }
    if (!blob || blob.size < 1 || blob.size > MAX_FILE) {
      alert('El informe esta vacio o supera los 100 MB permitidos.'); return;
    }
    var mime = /\.docx$/i.test(name) ?
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : 'application/pdf';
    running = true;
    try {
      if (!window.TecnoAndroid.begin(name, mime, blob.size)) {
        throw new Error('No se pudo iniciar el guardado en Android');
      }
      var partSize = 96 * 1024;
      for (var offset = 0; offset < blob.size; offset += partSize) {
        var part = blob.slice(offset, offset + partSize);
        window.TecnoAndroid.chunk(await readBase64(part));
      }
      window.TecnoAndroid.finish();
    } catch (err) {
      window.TecnoAndroid.cancel();
      alert('No se pudo preparar el informe: ' + (err.message || err));
    } finally {
      running = false;
    }
  }

  document.addEventListener('click', function (ev) {
    var target = ev.target;
    var a = target && target.closest ? target.closest('a[download]') : null;
    if (!a || !a.href || a.href.indexOf('blob:') !== 0) return;
    if (!/\.(pdf|docx)$/i.test(a.download || '')) return;
    ev.preventDefault();
    ev.stopImmediatePropagation();
    fetch(a.href).then(function (r) {
      if (!r.ok) throw new Error('No se pudo recuperar el archivo');
      return r.blob();
    }).then(function (blob) {
      return saveToAndroid(blob, a.download);
    }).catch(function (err) {
      alert('Error al preparar la descarga: ' + (err.message || err));
    });
  }, true);
})();
