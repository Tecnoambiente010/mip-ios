package cl.tecnoambiente.mip;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Contenedor Android MIP Metro/Ruta. Mantiene el sitio original, su almacenamiento
 * local, la firma tactil y la evidencia fotografica; agrega captura de fotos
 * y exportacion PDF/DOCX al Storage Access Framework de Android.
 *
 * AVISO: Esta aplicacion carga HTTPS desde un dominio autorizado. No agrega
 * contrasenas ni credenciales de Supabase al paquete.
 */
public final class MainActivity extends Activity {

    private static final String APP_URL = "https://tecnoambiente010.github.io/mip-ios/";
    private static final int SELECT_FILES = 1001;
    private static final int SAVE_DOCUMENT = 1002;
    private static final int GREEN = Color.rgb(47, 82, 51);
    private static final String PDF_MIME = "application/pdf";
    private static final String DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    private static final long MAX_FILE_BYTES = 100L * 1024 * 1024;

    private WebView web;
    private ProgressBar progress;
    private View noConnection;
    private ValueCallback<Uri[]> selectedFiles;
    private Uri cameraUri;
    private File cameraFile;
    private volatile boolean mainPageTrusted;

    private final Object downloadLock = new Object();
    private FileOutputStream receivingStream;
    private File receivingFile;
    private File fileReadyToSave;
    private long expectedBytes;
    private long receivedBytes;
    private String downloadName;
    private String downloadMime;
    private boolean downloadFailed;

    private int dp(float units) {
        return Math.round(getResources().getDisplayMetrics().density * units);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView.setWebContentsDebuggingEnabled(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(16), 0, dp(7), 0);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(GREEN);
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(47)));

        TextView title = new TextView(this);
        title.setText("TECNOAMBIENTE  ·  MIP");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button reload = new Button(this);
        reload.setText("Actualizar");
        reload.setAllCaps(false);
        reload.setTextSize(12);
        reload.setContentDescription("Recargar formulario MIP");
        reload.setOnClickListener(v -> web.reload());
        header.addView(reload, new LinearLayout.LayoutParams(-2, dp(42)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        FrameLayout pageArea = new FrameLayout(this);
        root.addView(pageArea, new LinearLayout.LayoutParams(-1, 0, 1));

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        pageArea.addView(web, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout errorPanel = new LinearLayout(this);
        errorPanel.setOrientation(LinearLayout.VERTICAL);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(dp(28), dp(28), dp(28), dp(28));
        errorPanel.setBackgroundColor(Color.WHITE);
        TextView error = new TextView(this);
        error.setGravity(Gravity.CENTER);
        error.setTextSize(17);
        error.setTextColor(Color.DKGRAY);
        error.setText("No se pudo abrir el formulario. Comprueba la conexión a Internet.\n\nLa primera carga requiere Internet; posteriormente, el sitio puede usar sus archivos guardados en caché.");
        errorPanel.addView(error, new LinearLayout.LayoutParams(-1, -2));
        Button retry = new Button(this);
        retry.setText("Reintentar");
        retry.setOnClickListener(v -> web.loadUrl(APP_URL));
        errorPanel.addView(retry);
        errorPanel.setVisibility(View.GONE);
        noConnection = errorPanel;
        pageArea.addView(errorPanel, new FrameLayout.LayoutParams(-1, -1));

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // fotos seleccionadas desde el sistema
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.addJavascriptInterface(new AndroidDownloadBridge(), "TecnoAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                mainPageTrusted = isAllowed(url);
                noConnection.setVisibility(View.GONE);
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                mainPageTrusted = isAllowed(url);
                progress.setVisibility(View.GONE);
                if (mainPageTrusted) injectDownloadInterceptor();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (isAllowed(url)) return false;
                if (request.isForMainFrame() && request.hasGesture() &&
                    (url.startsWith("https://") || url.startsWith("http://"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); }
                    catch (Exception ignored) { showToast("No hay una aplicación disponible para abrir el enlace."); }
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) noConnection.setVisibility(View.VISIBLE);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                noConnection.setVisibility(View.VISIBLE);
                showToast("No se pudo verificar la conexión segura.");
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (selectedFiles != null) selectedFiles.onReceiveValue(null);
                selectedFiles = callback;
                return openFileChooser(params);
            }
        });

        if (savedInstanceState != null) {
            String previousCapture = savedInstanceState.getString("camera_uri");
            String previousFile = savedInstanceState.getString("camera_file");
            if (previousCapture != null) cameraUri = Uri.parse(previousCapture);
            if (previousFile != null) cameraFile = new File(previousFile);
            if (web.restoreState(savedInstanceState) == null) web.loadUrl(APP_URL);
        } else {
            web.loadUrl(APP_URL);
        }
    }

    private boolean isAllowed(String value) {
        try {
            Uri uri = Uri.parse(value);
            return "https".equalsIgnoreCase(uri.getScheme()) &&
                "tecnoambiente010.github.io".equalsIgnoreCase(uri.getHost()) &&
                ("/mip-ios".equals(uri.getPath()) || uri.getPath().startsWith("/mip-ios/"));
        } catch (Exception ignored) { return false; }
    }

    private void injectDownloadInterceptor() {
        try (InputStream is = getAssets().open("android-download-bridge.js");
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder code = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) code.append(line).append('\n');
            web.evaluateJavascript(code.toString(), null);
        } catch (Exception err) {
            showToast("No se pudo activar la descarga nativa: " + err.getMessage());
        }
    }

    private boolean openFileChooser(WebChromeClient.FileChooserParams params) {
        try {
            Intent select = new Intent(Intent.ACTION_GET_CONTENT);
            select.addCategory(Intent.CATEGORY_OPENABLE);
            String[] accepts = params.getAcceptTypes();
            boolean photos = accepts == null || accepts.length == 0;
            if (accepts != null) for (String accept : accepts) {
                if (accept != null && (accept.contains("image") || accept.equals("*/*"))) photos = true;
            }
            select.setType(photos ? "image/*" : "*/*");
            select.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);

            List<Intent> alternatives = new ArrayList<>();
            if (photos) {
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (camera.resolveActivity(getPackageManager()) != null) {
                    cameraFile = File.createTempFile("mip_evidencia_", ".jpg", getCacheDir());
                    cameraUri = FileProvider.getUriForFile(this,
                        getPackageName() + ".provider", cameraFile);
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    camera.setClipData(ClipData.newRawUri("Fotografia MIP", cameraUri));
                    camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    alternatives.add(camera);
                }
            }
            Intent chooser = Intent.createChooser(select, "Seleccionar o tomar fotografía");
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, alternatives.toArray(new Intent[0]));
            startActivityForResult(chooser, SELECT_FILES);
            return true;
        } catch (Exception err) {
            showToast("No se pudo acceder a la cámara o archivos: " + err.getMessage());
            if (selectedFiles != null) selectedFiles.onReceiveValue(null);
            selectedFiles = null;
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SELECT_FILES) {
            if (selectedFiles == null) return;
            Uri[] chosen = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getClipData() != null) {
                    ClipData clips = data.getClipData();
                    chosen = new Uri[clips.getItemCount()];
                    for (int i = 0; i < clips.getItemCount(); i++) chosen[i] = clips.getItemAt(i).getUri();
                } else if (data != null && data.getData() != null) {
                    chosen = new Uri[]{data.getData()};
                } else if (cameraFile != null && cameraFile.length() > 0 && cameraUri != null) {
                    chosen = new Uri[]{cameraUri};
                }
            }
            selectedFiles.onReceiveValue(chosen);
            selectedFiles = null;
            cameraUri = null;
            cameraFile = null;
        } else if (requestCode == SAVE_DOCUMENT) {
            final File file;
            synchronized (downloadLock) {
                file = fileReadyToSave;
                fileReadyToSave = null;
            }
            if (file == null) return;
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                file.delete();
                showToast("Guardado cancelado. El borrador del formulario se conserva.");
                return;
            }
            final Uri destination = data.getData();
            new Thread(() -> {
                boolean success = false;
                try (InputStream src = new FileInputStream(file);
                     OutputStream target = getContentResolver().openOutputStream(destination, "w")) {
                    if (target == null) throw new java.io.IOException("Archivo destino no disponible");
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = src.read(buffer)) != -1) target.write(buffer, 0, read);
                    target.flush();
                    success = true;
                } catch (Exception ignored) { }
                finally { file.delete(); }
                final boolean saved = success;
                runOnUiThread(() -> showToast(saved ?
                    "Informe guardado en la ubicación seleccionada." :
                    "No fue posible guardar el informe. Inténtalo nuevamente."));
            }, "guardar-mip").start();
        }
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private final class AndroidDownloadBridge {
        @JavascriptInterface
        public boolean begin(String fileName, String mime, long size) {
            synchronized (downloadLock) {
                if (!mainPageTrusted || receivingStream != null || fileReadyToSave != null ||
                        size <= 0 || size > MAX_FILE_BYTES || fileName == null) return false;
                if (!(fileName.toLowerCase(Locale.ROOT).endsWith(".pdf") ||
                      fileName.toLowerCase(Locale.ROOT).endsWith(".docx"))) return false;
                if (!PDF_MIME.equals(mime) && !DOCX_MIME.equals(mime)) return false;
                try {
                    String name = fileName.replaceAll("[^a-zA-Z0-9À-ÿ._() -]", "_")
                        .replaceAll("^\\.+", "").trim();
                    if (name.isEmpty()) return false;
                    if (name.length() > 160) name = name.substring(0, 155) +
                        (name.endsWith(".pdf") ? ".pdf" : ".docx");
                    receivingFile = File.createTempFile("mip_descarga_", ".tmp", getCacheDir());
                    receivingStream = new FileOutputStream(receivingFile);
                    downloadName = name;
                    downloadMime = mime;
                    expectedBytes = size;
                    receivedBytes = 0;
                    downloadFailed = false;
                    return true;
                } catch (Exception ex) {
                    closeActiveLocked();
                    return false;
                }
            }
        }

        @JavascriptInterface
        public void chunk(String base64) {
            synchronized (downloadLock) {
                if (receivingStream == null || downloadFailed || base64 == null) return;
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    if (receivedBytes + bytes.length > expectedBytes ||
                        receivedBytes + bytes.length > MAX_FILE_BYTES) {
                        downloadFailed = true;
                        return;
                    }
                    receivingStream.write(bytes);
                    receivedBytes += bytes.length;
                } catch (Exception ex) { downloadFailed = true; }
            }
        }

        @JavascriptInterface
        public void finish() {
            final File ready;
            final String name;
            final String mime;
            synchronized (downloadLock) {
                if (receivingStream == null) return;
                if (downloadFailed || receivedBytes != expectedBytes) {
                    closeActiveLocked();
                    showToast("Descarga incompleta. Vuelve a generar el informe.");
                    return;
                }
                try { receivingStream.flush(); receivingStream.close(); }
                catch (Exception ex) { closeActiveLocked(); return; }
                receivingStream = null;
                ready = receivingFile;
                receivingFile = null;
                fileReadyToSave = ready;
                name = downloadName;
                mime = downloadMime;
            }
            runOnUiThread(() -> {
                try {
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType(mime);
                    save.putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(save, SAVE_DOCUMENT);
                } catch (Exception ex) {
                    synchronized (downloadLock) {
                        if (fileReadyToSave != null) fileReadyToSave.delete();
                        fileReadyToSave = null;
                    }
                    showToast("No se pudo abrir el selector de archivos de Android.");
                }
            });
        }

        @JavascriptInterface
        public void cancel() {
            synchronized (downloadLock) { closeActiveLocked(); }
        }
    }

    /** Debe llamarse bajo downloadLock. No elimina un archivo ya preparado para guardar. */
    private void closeActiveLocked() {
        try { if (receivingStream != null) receivingStream.close(); }
        catch (Exception ignored) { }
        if (receivingFile != null) receivingFile.delete();
        receivingStream = null;
        receivingFile = null;
        receivedBytes = 0;
        expectedBytes = 0;
        downloadFailed = false;
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        if (cameraUri != null) state.putString("camera_uri", cameraUri.toString());
        if (cameraFile != null) state.putString("camera_file", cameraFile.getAbsolutePath());
        web.saveState(state);
        super.onSaveInstanceState(state);
    }

    @Override
    public void onBackPressed() {
        if (noConnection.getVisibility() == View.VISIBLE) {
            noConnection.setVisibility(View.GONE);
            web.loadUrl(APP_URL);
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (selectedFiles != null) selectedFiles.onReceiveValue(null);
        synchronized (downloadLock) {
            closeActiveLocked();
            if (fileReadyToSave != null) fileReadyToSave.delete();
            fileReadyToSave = null;
        }
        if (web != null) {
            web.removeJavascriptInterface("TecnoAndroid");
            web.destroy();
        }
        super.onDestroy();
    }
}
